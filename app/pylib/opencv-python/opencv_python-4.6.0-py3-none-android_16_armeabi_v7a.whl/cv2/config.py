import os

BINARIES_PATHS = [
    '/home/binn/Projects/opencv460/opencv/build/lib'
] + BINARIES_PATHS
