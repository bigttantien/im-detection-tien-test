PYTHON_EXTENSIONS_PATHS = [
    '/home/binn/Projects/opencv460/opencv/build/lib/python3'
] + PYTHON_EXTENSIONS_PATHS
