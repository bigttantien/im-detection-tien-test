__version__ = '0.9.1'
git_version = '8fb5838ca916fd4ace080dae0357e7c307037bef'
from torchvision.extension import _check_cuda_version
if _check_cuda_version() > 0:
    cuda = _check_cuda_version()
